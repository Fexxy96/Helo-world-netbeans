/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaassignmentoperators;

/**
 *
 * @author Dell-User
 */
public class JavaAssignmentOperators {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        int x = 10;
        x += 5;
    }
}
