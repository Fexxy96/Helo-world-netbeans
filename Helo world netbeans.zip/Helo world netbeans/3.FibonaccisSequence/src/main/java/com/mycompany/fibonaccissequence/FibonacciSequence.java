/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.fibonaccissequence;

/**
 *
 * @author Dell-User
 */
import java.util.Scanner;
public class FibonacciSequence {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter the number of Fibonacci terms to generate: ");
            int numTerms = scanner.nextInt();
            
            if (numTerms <= 0) {
                System.out.println("Please enter a positive integer.");
            } else {
                int[] fibonacciSequence = generateFibonacci(numTerms);
                System.out.print("Fibonacci sequence up to " + numTerms + " terms: ");
                for (int i = 0; i < numTerms; i++) {
                    System.out.print(fibonacciSequence[i] + " ");
                }
                System.out.println();
            }
        }
    }
    
    public static int[] generateFibonacci(int n) {
        int[] fibonacciSequence = new int[n];
        
        if (n >= 1) {
            fibonacciSequence[0] = 0;
        }
        if (n >= 2) {
            fibonacciSequence[1] = 1;
        }
        for (int i = 2; i < n; i++) {
            fibonacciSequence[i] = fibonacciSequence[i - 1] + fibonacciSequence[i - 2];
        }
        
        return fibonacciSequence;
        
    }
}
