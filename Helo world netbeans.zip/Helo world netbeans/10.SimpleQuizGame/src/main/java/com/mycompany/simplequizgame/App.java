/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.simplequizgame;

/**
 *
 * @author Dell-User
 */
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
        
        // Define questions and answers
        String[] questions = {
            "What is the capital of South Africa?\nA. Johannesburg\nB. Durban\nC. Pretoria",
            "What is the largest planet in our solar system?\nA. Mars\nB. Jupiter\nC. Saturn",
            "Who wrote 'Romeo and Juliet'?\nA. William Shakespeare\nB. Charles Dickens\nC. Jane Austen"
        };
        String[] answers = {"A", "B", "A"};
        
        // Initialize variables to keep track of score
        int score = 0;
        
        // Ask questions
        for (int i = 0; i < questions.length; i++) {
            System.out.println(questions[i]);
            String userAnswer = scanner.nextLine().toUpperCase();
            if (userAnswer.equals(answers[i])) {
                System.out.println("Correct!\n");
                score++;
            } else {
                System.out.println("Incorrect!\n");
            }
        }
        
        // Display final score
        System.out.println("Quiz completed!\nYour score: " + score + "/" + questions.length);
        
        // Close scanner
        scanner.close();
    }
}
    

