/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.declaremanyvariables;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        
        int x = 5;
        int y = 6;
        int z = 50;
        System.out.println(x+y+z);
        
        
                       
    }
}
