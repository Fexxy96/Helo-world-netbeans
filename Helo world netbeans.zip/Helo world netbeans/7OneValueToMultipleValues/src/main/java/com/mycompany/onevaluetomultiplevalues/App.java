/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.onevaluetomultiplevalues;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        int x, y, z;
        x= y = z  =50;
        System.out.println(x + y + z);
        
        
    }
}
