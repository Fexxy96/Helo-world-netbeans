/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaprintvariables;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        String name = "John";
        System.out.println("hello" + name);
        String firstName = "John";
        String lastName = "Doe";
        String fullName = firstName + lastName;
        System.out.println(fullName);
        
        int x = 5;
        int y = 6;
        System.out.println(x + y); // Print the values of x+y
                
                
       
        
        
    }
}
