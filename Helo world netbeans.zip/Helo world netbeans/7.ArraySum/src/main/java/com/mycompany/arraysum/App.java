/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arraysum;

/**
 *
 * @author Dell-User
 */
import java.util.Scanner;
public class App {

    public static void main(String[] args) {
        // Prompt user for the size of the array
        try (Scanner scanner = new Scanner(System.in)) {
            // Prompt user for the size of the array
            System.out.print("Enter the size of the array: ");
            int size = scanner.nextInt();
            
            // Create an array of the specified size
            int[] arr = new int[size];
            
            // Prompt user to input array elements
            System.out.println("Enter the elements of the array:");
            for (int i = 0; i < size; i++) {
                System.out.print("Element " + (i+1) + ": ");
                arr[i] = scanner.nextInt();
            }
            
            // Calculate the sum of elements in the array
            int sum = 0;
            for (int num : arr) {
                sum += num;
            }
            
            // Display the sum
            System.out.println("Sum of elements in the array: " + sum);
        }
    }
}   

