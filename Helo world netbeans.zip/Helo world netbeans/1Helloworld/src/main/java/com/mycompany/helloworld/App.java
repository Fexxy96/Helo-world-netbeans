/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.helloworld;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        System.out.println("i am learning Java.");
        System.out.println("It is Awesome!");
    }
}
