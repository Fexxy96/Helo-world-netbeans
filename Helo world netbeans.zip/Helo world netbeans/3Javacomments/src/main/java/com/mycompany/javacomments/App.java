/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javacomments;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        // This is a comment
        System.out.println("Hello World");
        
        System.out.println("Hello World"); // This is a comment
        
        /* The code below will print the words Hello World to the screen,
        and is amazing */
       System.out.println("Hello World");
       
       
    }
}
