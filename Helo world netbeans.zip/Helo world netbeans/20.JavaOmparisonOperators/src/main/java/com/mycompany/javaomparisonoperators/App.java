/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaomparisonoperators;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        int x = 5;
        int y =3;
        System.out.println(x > y); //returns true because 5 is higher than 3
    }
}
