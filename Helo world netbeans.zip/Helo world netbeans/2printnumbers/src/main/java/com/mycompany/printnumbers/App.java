/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.printnumbers;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        System.out.println(3);
        System.out.println(358);
        System.out.println(50000);
        System.out.println(3 + 3);
        System.out.println(3 - 3);
        System.out.println(2 * 3);
        System.out.println(8 / 2);
        
        
        
        
        
        
        
    }
}
