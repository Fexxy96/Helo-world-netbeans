/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javacharacters;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        
        char myGrade - 'B';
        System.out.println(myGrade);
        
        String greeting - "Hello World!";
        
        System.out.println(greeting);
        
    }
}
