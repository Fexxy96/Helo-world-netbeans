/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaidentifiers;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        //Good
        int minutesPerHour = 60;
        
        //OK, but not so easy to understand what m actually is
        int m = 60
    }
}
