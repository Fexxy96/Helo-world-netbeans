/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.wordcount;

/**
 *
 * @author Dell-User
 */
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Enter a sentence:");
            String sentence = scanner.nextLine();
            
            int wordCount = countWords(sentence);
            
            System.out.println("Number of words in the sentence: " + wordCount);
        }
    }
    
    public static int countWords(String sentence) {
        int count = 0;
        boolean isWord = false;
        int endOfLine = sentence.length() - 1;

        for (int i = 0; i <= endOfLine; i++) {
            // If the current character is a letter, mark it as part of a word
            if (Character.isLetter(sentence.charAt(i)) && i != endOfLine) {
                isWord = true;
            // If it's a non-letter and the previous character was part of a word, increment count
            } else if (!Character.isLetter(sentence.charAt(i)) && isWord) {
                count++;
                isWord = false;
            // If it's the last character and it's a letter, increment count as well
            } else if (Character.isLetter(sentence.charAt(i)) && i == endOfLine) {
                count++;
            }
        }
        
        return count;
    }
}  
    

