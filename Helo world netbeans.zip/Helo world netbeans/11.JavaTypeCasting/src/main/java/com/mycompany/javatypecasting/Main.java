/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javatypecasting;

/**
 *
 * @author Dell-User
 */
public class Main {

    public static void main(String[] args) {
        int myInt = 9;
        double my;
        double myDouble = my Int; //Automatic casting: int to double
        
        System.out.println(myInt); //Outputs 9
        System.out.println(myDouble); // Outputs 9.0
    }
}
