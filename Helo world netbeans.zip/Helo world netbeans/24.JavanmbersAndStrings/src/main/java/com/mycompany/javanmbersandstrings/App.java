/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javanmbersandstrings;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        int x = 10;
        int y = 20;
        int z = x + y;
        System.out.println(z);
        
        String a = "10";
        String b = "20";
        String c = a + b;
        System.out.println(c);
        
    }
}
