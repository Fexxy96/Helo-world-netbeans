/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javavariables;

/**
 *
 * @author Dell-User
 */
public class Javavariables {

    public static void main(String[] args) 
    {
        System.out.println("Hello World!");
        String name = "John";
       System.out.println(name);
       
       int myNum = 5;
       float myFloatNum = 5.99f;
       char myLetter = 'D';
       boolean myBool = true;
       String myText = "Hello World";
               
               
       System.out.println(myNum);
       System.out.println(myFloatNum);
       System.out.println(myLetter);
       System.out.println(myBool);
       System.out.println(myText);
       
    }
}
